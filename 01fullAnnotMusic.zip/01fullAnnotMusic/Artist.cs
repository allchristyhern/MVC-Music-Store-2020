﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;


namespace EmptyCodeFirstDemo.Models
{
    public class Artist
    {
        public int ArtistId { get; set; }

        [Required]
        [DisplayName("Artist(s)/Band: ")]
        public string Name { get; set; }
    }
}
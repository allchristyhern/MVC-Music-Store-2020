﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace EmptyCodeFirstDemo.Models
{
    public class Cart
    {
        [Key]
        public int RecordId  { get; set; }
        public string CartId { get; set; }
        public int AlbumId   { get; set; }

        [DisplayName("Count: ")]
        public int Count     { get; set; }

        [DataType(DataType.DateTime)]
        [DisplayName("Date Created: ")]
        public DateTime DateCreated { get; set; }

        public virtual Album Album  { get; set; }
    }
}